// AngelLive Chaturbate 插件 v1.3.0
// 公开房列表 + HLS 播放（不绕过私人房）
//
// v1.3.0:
// - LiveQualityModel：liveCodeType=m3u8 / streamFormat=hlsLive（与 Videosection 一致）
// - PluginRoomDTO：标题纯 ASCII，封面自拼，分类 id 用 girls/couples 不用 f/c#
// - getPlayback 不预拉 master，避免 403 session_duplicated

(function () {
  var UA =
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
  var SITE = "https://chaturbate.com";
  var PAGE_SIZE = 24;
  var PLATFORM_ID = "chaturbate";

  function asText(v) {
    if (v == null) return "";
    return String(v);
  }

  function asciiName(v) {
    var s = asText(v).trim();
    var out = "";
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      var code = s.charCodeAt(i);
      if (
        (code >= 48 && code <= 57) ||
        (code >= 65 && code <= 90) ||
        (code >= 97 && code <= 122) ||
        c === "_" ||
        c === "-"
      ) {
        out += c;
      }
    }
    return out;
  }

  function getCookie() {
    try {
      if (Host.session && typeof Host.session.getCookieHeader === "function") {
        var c = Host.session.getCookieHeader(PLATFORM_ID);
        if (c && String(c).trim()) return String(c).trim();
      }
    } catch (e) {}
    return "";
  }

  function baseHeaders() {
    var h = {
      "User-Agent": UA,
      Referer: SITE + "/",
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9"
    };
    var cookie = getCookie();
    if (cookie) h["Cookie"] = cookie;
    return h;
  }

  async function httpGetText(url, headers, timeout) {
    timeout = timeout || 15;
    try {
      var resp = await Host.http.request({
        url: url,
        method: "GET",
        headers: headers || baseHeaders(),
        timeout: timeout
      });
      if (!resp || resp.status < 200 || resp.status >= 300) return "";
      return asText(resp.bodyText || resp.body || "");
    } catch (e) {
      return "";
    }
  }

  async function httpPostText(url, body, headers, timeout) {
    timeout = timeout || 15;
    try {
      var h = Object.assign({}, headers || baseHeaders());
      h["Content-Type"] = "application/x-www-form-urlencoded";
      h["X-Requested-With"] = "XMLHttpRequest";
      var resp = await Host.http.request({
        url: url,
        method: "POST",
        headers: h,
        body: body,
        timeout: timeout
      });
      if (!resp || resp.status < 200 || resp.status >= 300) return "";
      return asText(resp.bodyText || resp.body || "");
    } catch (e) {
      return "";
    }
  }

  async function httpGetJSON(url, headers) {
    var text = await httpGetText(url, headers || baseHeaders(), 20);
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  function isPaidOrLocked(r) {
    if (!r) return true;
    if (r.has_password) return true;
    var show = asText(r.current_show || r.label || "").toLowerCase();
    return (
      show === "private" ||
      show === "hidden" ||
      show === "group" ||
      show === "ticket"
    );
  }

  function mapRoom(r) {
    if (!r) return null;
    var username = asciiName(r.username);
    if (!username) return null;

    var viewers = parseInt(r.num_users, 10);
    if (isNaN(viewers) || viewers < 0) viewers = 0;

    var cover = "https://thumb.live.mmcdn.com/ri/" + username + ".jpg";
    var title = username;
    if (viewers) title = username + " " + String(viewers);

    return {
      userName: username,
      roomTitle: title,
      roomCover: cover,
      userHeadImg: cover,
      liveState: "live",
      userId: username,
      roomId: username,
      liveWatchedCount: String(viewers)
    };
  }

  function genderFromId(id) {
    id = asText(id).toLowerCase();
    if (id.indexOf("couple") === 0 || id === "c" || id === "c_root") return "c";
    if (id.indexOf("men") === 0 || id === "m" || id === "m_root" || id === "male") return "m";
    if (id.indexOf("trans") === 0 || id === "t" || id === "t_root") return "t";
    return "f";
  }

  function filterFromId(id) {
    id = asText(id).toLowerCase();
    if (id.indexOf("free") !== -1) return "free";
    if (id.indexOf("paid") !== -1 || id.indexOf("lock") !== -1) return "paid";
    return "";
  }

  async function fetchRoomList(genders, page, keywords) {
    page = page || 1;
    var offset = (page - 1) * PAGE_SIZE;
    var url =
      SITE +
      "/api/ts/roomlist/room-list/?limit=" +
      PAGE_SIZE +
      "&offset=" +
      offset;
    if (genders) url += "&genders=" + encodeURIComponent(genders);
    if (keywords) url += "&keywords=" + encodeURIComponent(keywords);
    try {
      var data = await httpGetJSON(url);
      if (!data || !Array.isArray(data.rooms)) return [];
      return data.rooms;
    } catch (e) {
      return [];
    }
  }

  async function getCategories() {
    return [
      {
        id: "girls_root",
        title: "Girls",
        icon: "",
        subList: [
          { id: "girls", parentId: "girls_root", title: "All Girls", icon: "" },
          { id: "girls_free", parentId: "girls_root", title: "Public Free", icon: "" }
        ]
      },
      {
        id: "couples_root",
        title: "Couples",
        icon: "",
        subList: [
          { id: "couples", parentId: "couples_root", title: "All Couples", icon: "" },
          { id: "couples_free", parentId: "couples_root", title: "Public Free", icon: "" }
        ]
      },
      {
        id: "men_root",
        title: "Men",
        icon: "",
        subList: [
          { id: "men", parentId: "men_root", title: "All Men", icon: "" },
          { id: "men_free", parentId: "men_root", title: "Public Free", icon: "" }
        ]
      },
      {
        id: "trans_root",
        title: "Trans",
        icon: "",
        subList: [
          { id: "trans", parentId: "trans_root", title: "All Trans", icon: "" },
          { id: "trans_free", parentId: "trans_root", title: "Public Free", icon: "" }
        ]
      }
    ];
  }

  async function getRooms(payload) {
    try {
      payload = payload || {};
      var id = asText(payload.id || "girls");
      var page = payload.page || 1;
      var gender = genderFromId(id);
      var filterMode = filterFromId(id);
      var roomsRaw = await fetchRoomList(gender, page, "");
      var rooms = [];
      for (var i = 0; i < roomsRaw.length; i++) {
        var r = roomsRaw[i];
        if (filterMode === "free" && isPaidOrLocked(r)) continue;
        if (filterMode === "paid" && !isPaidOrLocked(r)) continue;
        var mapped = mapRoom(r);
        if (mapped) rooms.push(mapped);
      }
      return rooms;
    } catch (e) {
      return [];
    }
  }

  async function search(payload) {
    try {
      payload = payload || {};
      var keyword = asciiName(payload.keyword || "");
      if (!keyword) return [];
      var page = payload.page || 1;
      var roomsRaw = await fetchRoomList("", page, keyword);
      if (!roomsRaw.length) {
        roomsRaw = await fetchRoomList("f", 1, "");
        var kw = keyword.toLowerCase();
        roomsRaw = roomsRaw.filter(function (r) {
          return asciiName(r && r.username).toLowerCase().indexOf(kw) !== -1;
        });
      }
      var rooms = [];
      for (var i = 0; i < roomsRaw.length; i++) {
        var mapped = mapRoom(roomsRaw[i]);
        if (mapped) rooms.push(mapped);
      }
      return rooms;
    } catch (e) {
      return [];
    }
  }

  function makeRoom(roomId, liveState) {
    roomId = asciiName(roomId) || "unknown";
    var cover = "https://thumb.live.mmcdn.com/ri/" + roomId + ".jpg";
    return {
      userName: roomId,
      roomTitle: roomId,
      roomCover: cover,
      userHeadImg: cover,
      liveState: liveState || "unknow",
      userId: roomId,
      roomId: roomId,
      liveWatchedCount: "0"
    };
  }

  async function getRoomDetail(payload) {
    try {
      payload = payload || {};
      var roomId = asciiName(payload.roomId || payload.userId || "");
      if (!roomId) return makeRoom("unknown", "unknow");
      var status = await getStreamInfo(roomId);
      var liveState = "unknow";
      if (status && asText(status.room_status).toLowerCase() === "public" && status.url) {
        liveState = "live";
      }
      return makeRoom(roomId, liveState);
    } catch (e) {
      return makeRoom((payload && (payload.roomId || payload.userId)) || "unknown", "unknow");
    }
  }

  async function getLiveState(payload) {
    try {
      var roomId = asciiName((payload && payload.roomId) || "");
      if (!roomId) return { liveState: "unknow" };
      var status = await getStreamInfo(roomId);
      if (status && asText(status.room_status).toLowerCase() === "public" && status.url) {
        return { liveState: "live" };
      }
      return { liveState: "unknow" };
    } catch (e) {
      return { liveState: "unknow" };
    }
  }

  async function getStreamInfo(username) {
    username = asciiName(username);
    if (!username) return null;

    try {
      var body = "room_slug=" + encodeURIComponent(username) + "&bandwidth=high";
      var text = await httpPostText(
        SITE + "/get_edge_hls_url_ajax/",
        body,
        Object.assign(baseHeaders(), { Referer: SITE + "/" + username + "/" }),
        12
      );
      if (text) {
        var j = JSON.parse(text);
        if (j && j.url) {
          return {
            room_status: asText(j.room_status),
            url: asText(j.url),
            hls_source: asText(j.url)
          };
        }
        if (j) {
          return {
            room_status: asText(j.room_status),
            url: "",
            hls_source: ""
          };
        }
      }
    } catch (e) {}

    try {
      var j2 = await httpGetJSON(SITE + "/api/chatvideocontext/" + username + "/");
      if (j2) {
        return {
          room_status: asText(j2.room_status),
          url: asText(j2.hls_source),
          hls_source: asText(j2.hls_source)
        };
      }
    } catch (e2) {}

    return null;
  }

  async function getPlayback(payload) {
    var roomId = asciiName((payload && payload.roomId) || "");
    if (!roomId) Host.raise("INVALID_ARGS", "missing roomId");

    var info = await getStreamInfo(roomId);
    if (!info) Host.raise("UPSTREAM", "room status unavailable");

    var rs = asText(info.room_status).toLowerCase();
    if (rs === "private" || rs === "hidden") {
      Host.raise("UPSTREAM", "private room");
    }
    if (rs === "away" || rs === "offline") {
      Host.raise("UPSTREAM", "offline");
    }

    var masterUrl = asText(info.url || info.hls_source);
    if (!masterUrl || masterUrl.indexOf("http") !== 0) {
      Host.raise("UPSTREAM", "no stream url");
    }

    // 不要 GET master：CDN token 一次性，预拉会导致播放器 403 session_duplicated
    // LiveQualityModel 字段与 Videosection 对齐：m3u8 + hlsLive + lowLatency
    return [
      {
        cdn: "chaturbate",
        displayName: "Chaturbate",
        qualitys: [
          {
            roomId: roomId,
            title: "Auto",
            qn: 0,
            url: masterUrl,
            liveCodeType: "m3u8",
            liveType: "chaturbate",
            userAgent: UA,
            headers: {
              Referer: SITE + "/" + roomId + "/",
              "User-Agent": UA
            },
            playbackHints: {
              streamFormat: "hlsLive",
              latencyMode: "lowLatency",
              isLive: true
            }
          }
        ]
      }
    ];
  }

  async function resolveShare(payload) {
    var code = asText(payload && payload.shareCode);
    var match =
      code.match(/chaturbate\.(?:com|eu|global)\/([a-zA-Z0-9_-]+)/i) ||
      code.match(/^\/?([a-zA-Z0-9_-]+)\/?$/);
    if (!match) Host.raise("INVALID_ARGS", "unrecognized Chaturbate room");
    return getRoomDetail({ roomId: match[1] });
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState,
    getPlayback: getPlayback,
    resolveShare: resolveShare
  };
})();
