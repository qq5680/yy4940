// AngelLive Chaturbate 插件 v1.2.0
// 公开房列表 + HLS 播放（不绕过私人房）
//
// 列表注意：
// PluginRoomDTO.liveState 只认 live / unknow。返回 close 或网络异常对象，
// Swift 会报 Decoding Array<PluginRoomDTO> failed。
//
// 播放注意：
// Chaturbate 边缘 HLS 是一次性 token + session。插件如果自己先 GET 一遍 master，
// 播放器再去拉同一条 URL 会直接 403（w3: session_duplicated）。
// 所以 getPlayback 只解析房间状态、把 master 原样交给播放器，不再预拉 playlist。
// 变体 URI 是站点根路径（/v1/edge/...），不能拼到 master 目录后面。
// 另外 Origin 头会触发 403，播放请求不要带 Origin。

(function () {
  var UA =
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
  var SITE = "https://chaturbate.com";
  var PAGE_SIZE = 36;
  var PLATFORM_ID = "chaturbate";

  function asText(v) {
    if (v == null) return "";
    return String(v);
  }

  function cleanText(v) {
    var s = asText(v)
      .replace(/<[^>]+>/g, " ")
      .replace(/[\u0000-\u001F\u007F]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return s;
  }

  function getCookie() {
    try {
      if (Host.session && typeof Host.session.getCookieHeader === "function") {
        var c = Host.session.getCookieHeader(PLATFORM_ID);
        if (c && String(c).trim()) return String(c).trim();
      }
    } catch (e) {}
    return "";
  }

  function baseHeaders() {
    var h = {
      "User-Agent": UA,
      Referer: SITE + "/",
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8"
    };
    var cookie = getCookie();
    if (cookie) h["Cookie"] = cookie;
    return h;
  }

  async function httpGetText(url, headers, timeout) {
    timeout = timeout || 15;
    try {
      var resp = await Host.http.request({
        url: url,
        method: "GET",
        headers: headers || baseHeaders(),
        timeout: timeout
      });
      if (!resp || resp.status < 200 || resp.status >= 300) return "";
      return asText(resp.bodyText || resp.body || "");
    } catch (e) {
      return "";
    }
  }

  async function httpPostText(url, body, headers, timeout) {
    timeout = timeout || 15;
    try {
      var h = Object.assign({}, headers || baseHeaders());
      h["Content-Type"] = "application/x-www-form-urlencoded";
      h["X-Requested-With"] = "XMLHttpRequest";
      var resp = await Host.http.request({
        url: url,
        method: "POST",
        headers: h,
        body: body,
        timeout: timeout
      });
      if (!resp || resp.status < 200 || resp.status >= 300) return "";
      return asText(resp.bodyText || resp.body || "");
    } catch (e) {
      return "";
    }
  }

  async function httpGetJSON(url, headers) {
    var text = await httpGetText(url, headers || baseHeaders(), 20);
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  function roomAccessLabel(r) {
    var show = String(r.current_show || r.label || "").toLowerCase();
    if (r.has_password) return "[PWD]";
    if (show === "private" || show === "hidden") return "[LOCK]";
    if (show === "group" || show === "ticket") return "[TICKET]";
    if (show === "away") return "[AWAY]";
    if (show === "offline") return "[OFF]";
    if (show === "public" || !show) return "[FREE]";
    return "[" + show + "]";
  }

  function isPaidOrLocked(r) {
    var show = String(r.current_show || r.label || "").toLowerCase();
    if (r.has_password) return true;
    if (show === "private" || show === "hidden" || show === "group" || show === "ticket") return true;
    return false;
  }

  function isPlayablePublic(r) {
    var show = String(r.current_show || r.label || "").toLowerCase();
    return show === "public" && !r.has_password;
  }

  function mapRoom(r) {
    if (!r) return null;
    var username = cleanText(r.username);
    if (!username) return null;
    if (!/^[a-zA-Z0-9_-]+$/.test(username)) return null;

    var viewers = parseInt(r.num_users, 10);
    if (isNaN(viewers) || viewers < 0) viewers = 0;
    var access = roomAccessLabel(r);
    // PluginRoomDTO 只认 live / unknow，不要返回 close
    var liveState = isPlayablePublic(r) ? "live" : "unknow";

    var cover = cleanText(r.img);
    if (!cover || cover.indexOf("http") !== 0) {
      cover = "https://thumb.live.mmcdn.com/ri/" + username + ".jpg";
    }

    var subject = cleanText(r.room_subject || "");
    if (subject.length > 36) subject = subject.substring(0, 36) + "...";
    var title = access + " " + username;
    if (viewers) title += " (" + viewers + ")";
    if (subject) title += " " + subject;

    return {
      userName: username,
      roomTitle: title,
      roomCover: cover,
      userHeadImg: cover,
      liveState: liveState,
      userId: username,
      roomId: username,
      liveWatchedCount: String(viewers)
    };
  }

  // genders: f / m / c / t
  async function fetchRoomList(genders, page, keywords) {
    page = page || 1;
    var offset = (page - 1) * PAGE_SIZE;
    var url =
      SITE +
      "/api/ts/roomlist/room-list/?limit=" +
      PAGE_SIZE +
      "&offset=" +
      offset;
    if (genders) url += "&genders=" + encodeURIComponent(genders);
    if (keywords) url += "&keywords=" + encodeURIComponent(keywords);

    try {
      var data = await httpGetJSON(url);
      if (!data || !data.rooms || !Array.isArray(data.rooms)) return [];
      return data.rooms;
    } catch (e) {
      return [];
    }
  }

  async function getCategories() {
    return [
      {
        id: "f_root",
        title: "👩 女生",
        icon: "",
        subList: [
          { id: "f", parentId: "f_root", title: "全部女生", icon: "" },
          { id: "f#free", parentId: "f_root", title: "🆓仅免费公开", icon: "" },
          { id: "f#paid", parentId: "f_root", title: "🔒仅私人/门票", icon: "" }
        ]
      },
      {
        id: "c_root",
        title: "💑 情侣",
        icon: "",
        subList: [
          { id: "c", parentId: "c_root", title: "全部情侣", icon: "" },
          { id: "c#free", parentId: "c_root", title: "🆓仅免费公开", icon: "" }
        ]
      },
      {
        id: "m_root",
        title: "👨 男主播",
        icon: "",
        subList: [
          { id: "m", parentId: "m_root", title: "全部男主播", icon: "" },
          { id: "m#free", parentId: "m_root", title: "🆓仅免费公开", icon: "" }
        ]
      },
      {
        id: "t_root",
        title: "⚧ 跨性别",
        icon: "",
        subList: [
          { id: "t", parentId: "t_root", title: "全部", icon: "" },
          { id: "t#free", parentId: "t_root", title: "🆓仅免费公开", icon: "" }
        ]
      }
    ];
  }

  async function getRooms(payload) {
    try {
      payload = payload || {};
      var id = String(payload.id || "f");
      var page = payload.page || 1;
      if (id === "f_root") id = "f";
      if (id === "c_root") id = "c";
      if (id === "m_root") id = "m";
      if (id === "t_root") id = "t";

      var filterMode = "";
      var hashIdx = id.indexOf("#");
      if (hashIdx !== -1) {
        filterMode = id.substring(hashIdx + 1);
        id = id.substring(0, hashIdx) || "f";
      }

      var gender = id; // f/m/c/t
      var roomsRaw = await fetchRoomList(gender, page, "");
      var rooms = [];
      for (var i = 0; i < roomsRaw.length; i++) {
        var r = roomsRaw[i];
        if (filterMode === "free" && isPaidOrLocked(r)) continue;
        if (filterMode === "paid" && !isPaidOrLocked(r)) continue;
        var mapped = mapRoom(r);
        if (mapped) rooms.push(mapped);
      }
      return rooms;
    } catch (e) {
      return [];
    }
  }

  async function search(payload) {
    try {
      payload = payload || {};
      var keyword = String(payload.keyword || "").trim();
      if (!keyword) return [];
      var page = payload.page || 1;
      var roomsRaw = await fetchRoomList("", page, keyword);
      if (!roomsRaw.length) {
        roomsRaw = await fetchRoomList("f", 1, "");
        var kw = keyword.toLowerCase();
        roomsRaw = roomsRaw.filter(function (r) {
          return String((r && r.username) || "").toLowerCase().indexOf(kw) !== -1;
        });
      }
      var rooms = [];
      for (var i = 0; i < roomsRaw.length; i++) {
        var mapped = mapRoom(roomsRaw[i]);
        if (mapped) rooms.push(mapped);
      }
      return rooms;
    } catch (e) {
      return [];
    }
  }

  function emptyRoom(roomId) {
    roomId = cleanText(roomId) || "unknown";
    var cover = "https://thumb.live.mmcdn.com/ri/" + roomId + ".jpg";
    return {
      userName: roomId,
      roomTitle: roomId,
      roomCover: cover,
      userHeadImg: cover,
      liveState: "unknow",
      userId: roomId,
      roomId: roomId,
      liveWatchedCount: "0"
    };
  }

  async function getRoomDetail(payload) {
    try {
      payload = payload || {};
      var roomId = cleanText(payload.roomId || payload.userId || "");
      if (!roomId) return emptyRoom("unknown");
      var cover = "https://thumb.live.mmcdn.com/ri/" + roomId + ".jpg";
      var status = await getStreamInfo(roomId);
      var liveState = "unknow";
      var access = "";
      if (status) {
        var rs = String(status.room_status || "").toLowerCase();
        if (rs === "public" && status.url) {
          liveState = "live";
          access = "FREE ";
        } else if (rs === "private" || rs === "hidden") {
          access = "LOCK ";
        }
      }
      return {
        userName: roomId,
        roomTitle: access + roomId,
        roomCover: cover,
        userHeadImg: cover,
        liveState: liveState,
        userId: roomId,
        roomId: roomId,
        liveWatchedCount: "0"
      };
    } catch (e) {
      return emptyRoom((payload && (payload.roomId || payload.userId)) || "unknown");
    }
  }

  async function getLiveState(payload) {
    try {
      var roomId = String((payload && payload.roomId) || "").trim();
      if (!roomId) return { liveState: "unknow" };
      var status = await getStreamInfo(roomId);
      if (!status) return { liveState: "unknow" };
      var rs = String(status.room_status || "").toLowerCase();
      if (rs === "public" && status.url) return { liveState: "live" };
      return { liveState: "unknow" };
    } catch (e) {
      return { liveState: "unknow" };
    }
  }

  // 返回 { room_status, url, hls_source }
  async function getStreamInfo(username) {
    username = String(username || "").trim();
    if (!username) return null;

    // 1) POST get_edge_hls_url_ajax
    try {
      var body = "room_slug=" + encodeURIComponent(username) + "&bandwidth=high";
      var text = await httpPostText(
        SITE + "/get_edge_hls_url_ajax/",
        body,
        Object.assign(baseHeaders(), {
          Referer: SITE + "/" + username + "/"
        }),
        12
      );
      if (text) {
        var j = JSON.parse(text);
        if (j) {
          return {
            room_status: j.room_status || "",
            url: j.url || "",
            hls_source: j.url || ""
          };
        }
      }
    } catch (e) {}

    // 2) GET chatvideocontext
    try {
      var j2 = await httpGetJSON(SITE + "/api/chatvideocontext/" + username + "/");
      if (j2) {
        return {
          room_status: j2.room_status || "",
          url: j2.hls_source || "",
          hls_source: j2.hls_source || ""
        };
      }
    } catch (e2) {}

    return null;
  }

  function streamHeaders(roomId) {
    return {
      Referer: SITE + "/" + roomId + "/",
      "User-Agent": UA,
      Accept: "*/*",
      "Accept-Language": "en-US,en;q=0.9"
    };
  }

  function makeQuality(roomId, title, qn, url) {
    return {
      roomId: roomId,
      title: title,
      qn: qn,
      url: url,
      liveCodeType: "hls",
      liveType: "chaturbate",
      userAgent: UA,
      headers: streamHeaders(roomId),
      playbackHints: {
        streamFormat: "hls",
        latencyMode: "low",
        isLive: true
      }
    };
  }

  async function getPlayback(payload) {
    var roomId = String(payload.roomId || "").trim();
    if (!roomId) Host.raise("INVALID_ARGS", "缺少 roomId");

    var info = await getStreamInfo(roomId);
    if (!info) Host.raise("UPSTREAM", "无法获取房间状态");

    var rs = String(info.room_status || "").toLowerCase();
    if (rs === "private" || rs === "hidden") {
      Host.raise("UPSTREAM", "该房间为私人房，无法播放公开流");
    }
    if (rs === "away" || rs === "offline") {
      Host.raise("UPSTREAM", "主播不在线");
    }
    if (rs === "password protected") {
      Host.raise("UPSTREAM", "密码房间，无法播放");
    }

    var masterUrl = info.url || info.hls_source || "";
    if (!masterUrl) {
      if (rs === "public") Host.raise("UPSTREAM", "公开房但无流地址（可能地区限制）");
      Host.raise("UPSTREAM", "无可用播放地址，状态: " + (rs || "unknown"));
    }

    // 不要在这里 GET master / chunklist：CDN 会把 token 绑到第一次请求，
    // 播放器再拉同一条 URL 会 403 session_duplicated。
    // 音视频分离 + LL-HLS，交给播放器自己解析 master 最稳。
    return [
      {
        cdn: "chaturbate",
        displayName: "Chaturbate",
        qualitys: [makeQuality(roomId, "自动", 10000, masterUrl)]
      }
    ];
  }

  async function resolveShare(payload) {
    var code = String(payload.shareCode || "");
    var match =
      code.match(/chaturbate\.(?:com|eu|global)\/([a-zA-Z0-9_-]+)/i) ||
      code.match(/^\/?([a-zA-Z0-9_-]+)\/?$/);
    if (!match) Host.raise("INVALID_ARGS", "无法识别 Chaturbate 房间");
    return getRoomDetail({ roomId: match[1] });
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState,
    getPlayback: getPlayback,
    resolveShare: resolveShare
  };
})();
