// AngelLive Stripchat 插件
// 女生分类 + 多CDN探测 + 广告过滤
// API: go.mavrtracktor.com

(function () {
  var UA =
    "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";
  var API_BASE = "https://go.mavrtracktor.com";
  var PAGE_SIZE = 50;

  var API_HEADERS = {
    "User-Agent": UA,
    Referer: "https://zh.stripchat.global/",
    Accept: "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7"
  };

  var HLS_HEADERS = {
    "User-Agent": UA,
    Referer: "https://stripchat.com/",
    Accept: "*/*",
    "Accept-Language": "en,zh-CN;q=0.9,zh;q=0.8"
  };

  // 女生分类
  var GIRLS_CATEGORIES = [
    { id: "girls", title: "全部女生" },
    { id: "girls/chinese", title: "中国女孩" },
    { id: "girls/japanese", title: "日本女孩" },
    { id: "girls/korean", title: "韩国女孩" },
    { id: "girls/asian", title: "亚洲人" },
    { id: "girls/teens", title: "少女18+" },
    { id: "girls/young", title: "鲜嫩青年22+" },
    { id: "girls/milfs", title: "熟女" },
    { id: "girls/mature", title: "成熟" },
    { id: "girls/new", title: "最新女主播" },
    { id: "girls/white", title: "白人" },
    { id: "girls/latin", title: "拉丁人" },
    { id: "girls/ebony", title: "黑珍珠" },
    { id: "girls/russian", title: "俄罗斯女孩" },
    { id: "girls/ukrainian", title: "乌克兰女孩" },
    { id: "girls/colombian", title: "哥伦比亚女孩" },
    { id: "girls/brazilian", title: "巴西女孩" },
    { id: "girls/american", title: "美国女孩" }
  ];

  var MEDIA_SUFFIXES = ["", "_source", "_orig", "_1600p", "_1080p", "_720p", "_480p", "_360p"];

  // ───────────────────────── HTTP ─────────────────────────

  async function httpGetText(url, headers, timeout) {
    timeout = timeout || 15;
    var resp = await Host.http.request({
      url: url,
      method: "GET",
      headers: headers || API_HEADERS,
      timeout: timeout
    });
    if (resp.status < 200 || resp.status >= 300) {
      return null;
    }
    return resp.bodyText || "";
  }

  async function httpGetJSON(url, headers) {
    var text = await httpGetText(url, headers || API_HEADERS, 20);
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  // ───────────────────────── 模型列表 ─────────────────────────

  async function fetchModels(tag, page) {
    page = page || 1;
    var offset = (page - 1) * PAGE_SIZE;
    var url =
      API_BASE +
      "/api/models?tag=" +
      encodeURIComponent(tag) +
      "&forceClient=1&stripcashR=0&limit=" +
      PAGE_SIZE +
      "&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai&offset=" +
      offset;
    var data = await httpGetJSON(url);
    if (!data) return [];
    return data.models || [];
  }

  function mapModel(model) {
    if (!model) return null;
    var gender = (model.gender || "").toLowerCase();
    // 只保留女生相关
    if (gender && gender.indexOf("female") === -1 && gender !== "tranny" && gender !== "femaletranny") {
      return null;
    }
    var username = String(model.username || "");
    var id = String(model.id || "");
    if (!username || !id) return null;

    var poster = model.snapshotUrl || model.previewUrlThumbBig || model.avatarUrl || "";
    var viewers = model.viewersCount || 0;

    return {
      userName: username,
      roomTitle: username + (viewers ? " (" + viewers + "人)" : ""),
      roomCover: poster,
      userHeadImg: model.avatarUrl || poster,
      liveState: model.status === "public" || !model.status ? "live" : "unknow",
      userId: id,
      roomId: id,
      liveWatchedCount: String(viewers)
    };
  }

  // ───────────────────────── 分类 ─────────────────────────

  async function getCategories() {
    var subList = [];
    for (var i = 0; i < GIRLS_CATEGORIES.length; i++) {
      var c = GIRLS_CATEGORIES[i];
      subList.push({
        id: c.id,
        parentId: "girls_root",
        title: c.title,
        icon: ""
      });
    }
    return [
      {
        id: "girls_root",
        title: "女生",
        icon: "",
        subList: subList
      }
    ];
  }

  // ───────────────────────── 房间列表 ─────────────────────────

  async function getRooms(payload) {
    var id = String(payload.id || "girls");
    var page = payload.page || 1;
    // 兼容根分类
    if (id === "girls_root" || id === "") id = "girls";

    var models = await fetchModels(id, page);
    var rooms = [];
    for (var i = 0; i < models.length; i++) {
      var r = mapModel(models[i]);
      if (r) rooms.push(r);
    }
    return rooms;
  }

  // ───────────────────────── 搜索 ─────────────────────────

  async function search(payload) {
    var keyword = String(payload.keyword || "").trim();
    if (!keyword) return [];
    var page = payload.page || 1;
    var offset = (page - 1) * PAGE_SIZE;
    var url =
      API_BASE +
      "/api/models?tag=girls&forceClient=1&stripcashR=0&limit=" +
      PAGE_SIZE +
      "&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai&offset=" +
      offset +
      "&search=" +
      encodeURIComponent(keyword);
    var data = await httpGetJSON(url);
    if (!data) return [];
    var models = data.models || [];
    var rooms = [];
    for (var i = 0; i < models.length; i++) {
      var r = mapModel(models[i]);
      if (r) rooms.push(r);
    }
    return rooms;
  }

  // ───────────────────────── 房间详情 / 状态 ─────────────────────────

  async function getRoomDetail(payload) {
    var roomId = String(payload.roomId || "");
    // 尝试用搜索反查用户名等信息
    var models = await fetchModels("girls", 1);
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === roomId) {
        found = models[i];
        break;
      }
    }
    if (!found) {
      // 兜底
      return {
        userName: roomId,
        roomTitle: "房间 " + roomId,
        roomCover: "",
        userHeadImg: "",
        liveState: "live",
        userId: roomId,
        roomId: roomId
      };
    }
    var mapped = mapModel(found);
    return mapped || {
      userName: found.username || roomId,
      roomTitle: found.username || roomId,
      roomCover: found.snapshotUrl || "",
      userHeadImg: found.avatarUrl || "",
      liveState: "live",
      userId: roomId,
      roomId: roomId,
      liveWatchedCount: String(found.viewersCount || 0)
    };
  }

  async function getLiveState(payload) {
    // 简单返回 live，实际播放时再验证
    return { liveState: "live" };
  }

  // ───────────────────────── 播放地址（核心：过滤广告） ─────────────────────────

  function buildMasterUrls(roomId) {
    var id = String(roomId);
    return [
      "https://edge-hls.doppiocdn.org/hls/" + id + "/master/" + id + "_auto.m3u8",
      "https://edge-hls.doppiocdn.com/hls/" + id + "/master/" + id + "_auto.m3u8",
      "https://edge-hls.doppiocdn.org/hls/" + id + "/master/" + id + ".m3u8",
      "https://edge-hls.doppiocdn.com/hls/" + id + "/master/" + id + ".m3u8",
      "https://edge-hls.growcdnssedge.com/hls/" + id + "/master/" + id + "_auto.m3u8",
      "https://edge-hls.growcdnssedge.com/hls/" + id + "/master/" + id + ".m3u8"
    ];
  }

  function extractPkey(m3u8Text) {
    var needle = "#EXT-X-MOUFLON:PSCH:v2:";
    var idx = m3u8Text.indexOf(needle);
    if (idx === -1) return "";
    var lineEnd = m3u8Text.indexOf("\n", idx);
    var line = m3u8Text.substring(idx, lineEnd === -1 ? m3u8Text.length : lineEnd).trim();
    var parts = line.split(":");
    if (parts.length >= 4) return parts[parts.length - 1];
    return "";
  }

  function isAdPlaylist(text) {
    if (!text) return true;
    var t = text.toLowerCase();
    if (t.indexOf("#ext-x-mouflon-advert") !== -1) return true;
    if (t.indexOf("cpa/v2/") !== -1) return true;
    if (t.indexOf("#ext-x-playlist-type:vod") !== -1) return true;
    if (t.indexOf("#extinf") === -1) return true;
    return false;
  }

  async function isLiveMedia(url, pkey) {
    var probe = url;
    if (pkey && probe.indexOf("pkey=") === -1) {
      probe += (probe.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency&psch=v2&pkey=" + pkey;
    } else if (probe.indexOf("playlistType") === -1) {
      probe += (probe.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency";
    }
    var text = await httpGetText(probe, HLS_HEADERS, 8);
    if (!text || isAdPlaylist(text)) return false;
    return true;
  }

  function toGrowMediaUrl(input) {
    if (!input) return null;
    return String(input).replace(
      /https?:\/\/media-hls\.doppiocdn\.(?:org|com|net)\/b-hls-\d+\//i,
      "https://media-hls.growcdnssedge.com/b-hls-10/"
    );
  }

  async function resolveBestStream(roomId) {
    var id = String(roomId);
    var pkey = "";
    var masterVariants = [];

    // 1. 探测 master
    var masters = buildMasterUrls(id);
    for (var mi = 0; mi < masters.length; mi++) {
      var text = await httpGetText(masters[mi], HLS_HEADERS, 8);
      if (!text || text.indexOf("#EXTM3U") === -1) continue;
      if (!pkey) pkey = extractPkey(text);

      var lines = text.split(/\r?\n/);
      var base = masters[mi].replace(/\/[^/]*$/, "/");
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
        if (/blurred/i.test(line)) continue;
        var next = i + 1 < lines.length ? lines[i + 1].trim() : "";
        if (!next || next.charAt(0) === "#") continue;
        var varUrl = next.indexOf("http") === 0 ? next : base + next;
        var nameMatch = line.match(/NAME="([^"]+)"/i);
        masterVariants.push({ name: nameMatch ? nameMatch[1] : "", url: varUrl });
      }
      if (masterVariants.length > 0) break;
    }

    // 2. 优先 grow media 高画质
    var candidates = [];
    var baseGrow = "https://media-hls.growcdnssedge.com/b-hls-10/" + id + "/" + id;
    for (var s = 0; s < MEDIA_SUFFIXES.length; s++) {
      candidates.push(baseGrow + MEDIA_SUFFIXES[s] + ".m3u8");
    }
    for (var v = 0; v < masterVariants.length; v++) {
      var g = toGrowMediaUrl(masterVariants[v].url);
      if (g && g.indexOf("growcdnssedge") !== -1) candidates.push(g);
    }

    var seen = {};
    for (var c = 0; c < candidates.length; c++) {
      var cand = candidates[c];
      if (seen[cand]) continue;
      seen[cand] = true;
      if (await isLiveMedia(cand, pkey)) {
        var finalUrl = cand;
        if (pkey && finalUrl.indexOf("pkey=") === -1) {
          finalUrl += (finalUrl.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency&psch=v2&pkey=" + pkey;
        } else if (finalUrl.indexOf("playlistType") === -1) {
          finalUrl += (finalUrl.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency";
        }
        return finalUrl;
      }
    }

    // 3. master 变体兜底
    for (var mv = 0; mv < masterVariants.length; mv++) {
      var vu = masterVariants[mv].url;
      if (await isLiveMedia(vu, pkey)) {
        var fu = vu;
        if (pkey && fu.indexOf("pkey=") === -1) {
          fu += (fu.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency&psch=v2&pkey=" + pkey;
        } else if (fu.indexOf("playlistType") === -1) {
          fu += (fu.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency";
        }
        return fu;
      }
    }

    // 4. 最终兜底
    return (
      "https://edge-hls.doppiocdn.org/hls/" +
      id +
      "/master/" +
      id +
      "_auto.m3u8?playlistType=lowLatency"
    );
  }

  async function getPlayback(payload) {
    var roomId = String(payload.roomId || "");
    if (!roomId) {
      Host.raise("INVALID_ARGS", "缺少 roomId");
    }

    var streamUrl = await resolveBestStream(roomId);
    if (!streamUrl) {
      Host.raise("UPSTREAM", "无法获取播放地址");
    }

    // 返回单线路（已过滤广告的最佳源）
    return [
      {
        cdn: "stripchat",
        displayName: "Stripchat",
        qualitys: [
          {
            roomId: roomId,
            title: "自动",
            qn: 0,
            url: streamUrl,
            liveCodeType: "hls",
            liveType: "stripchat",
            userAgent: UA,
            headers: {
              Referer: "https://stripchat.com/",
              "User-Agent": UA
            },
            playbackHints: {
              streamFormat: "hls",
              latencyMode: "low",
              isLive: true
            }
          }
        ]
      }
    ];
  }

  // ───────────────────────── 分享解析 ─────────────────────────

  async function resolveShare(payload) {
    var code = String(payload.shareCode || "");
    // 支持 https://stripchat.com/username 或纯用户名
    var match = code.match(/stripchat\.com\/([a-zA-Z0-9_-]+)/i) || code.match(/^([a-zA-Z0-9_-]+)$/);
    if (!match) {
      Host.raise("INVALID_ARGS", "无法识别 Stripchat 房间");
    }
    var username = match[1];
    // 通过搜索反查 id
    var models = await fetchModels("girls", 1);
    // 更准确：带 search
    var url =
      API_BASE +
      "/api/models?tag=girls&forceClient=1&limit=10&search=" +
      encodeURIComponent(username);
    var data = await httpGetJSON(url);
    var list = (data && data.models) || [];
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].username).toLowerCase() === username.toLowerCase()) {
        var mapped = mapModel(list[i]);
        if (mapped) return mapped;
      }
    }
    Host.raise("UPSTREAM", "未找到该主播或已下播");
  }

  // ───────────────────────── 导出 ─────────────────────────

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState,
    getPlayback: getPlayback,
    resolveShare: resolveShare
  };
})();
